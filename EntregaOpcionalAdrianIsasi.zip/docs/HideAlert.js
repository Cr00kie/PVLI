
const alertBlock = document.getElementById('alert-block');
const okButton = document.getElementById('hide-alert-button');

okButton.onclick = () => alertBlock.style.display = 'none';